package com.brawldraftai.app;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(12, 18, 32);
    private final int panel = Color.rgb(25, 35, 55);
    private final int blue = Color.rgb(65, 125, 245);
    private final int white = Color.WHITE;
    private final int muted = Color.rgb(170, 185, 210);
    private final int green = Color.rgb(64, 190, 140);
    private final int warning = Color.rgb(255, 190, 100);

    private Spinner mapProfileSpinner;
    private Spinner modeSpinner;
    private EditText mapNameInput;
    private EditText alliesInput;
    private EditText enemiesInput;
    private EditText bansInput;
    private LinearLayout content;
    private LinearLayout resultArea;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        showHome();
        if (state != null) restoreState(state);
    }

    @Override
    protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        if (mapProfileSpinner != null && mapProfileSpinner.getSelectedItemPosition() >= 0) {
            state.putInt("map_profile", mapProfileSpinner.getSelectedItemPosition());
        }
        if (modeSpinner != null && modeSpinner.getSelectedItemPosition() >= 0) {
            state.putInt("mode", modeSpinner.getSelectedItemPosition());
        }
        if (mapNameInput != null) state.putString("map_name", mapNameInput.getText().toString());
        if (alliesInput != null) state.putString("allies", alliesInput.getText().toString());
        if (enemiesInput != null) state.putString("enemies", enemiesInput.getText().toString());
        if (bansInput != null) state.putString("bans", bansInput.getText().toString());
        state.putBoolean("has_analyzed", resultArea != null && resultArea.getChildCount() > 0);
    }

    private void restoreState(Bundle state) {
        mapProfileSpinner.setSelection(state.getInt("map_profile", 0));
        modeSpinner.setSelection(state.getInt("mode", 0));
        mapNameInput.setText(state.getString("map_name", ""));
        alliesInput.setText(state.getString("allies", ""));
        enemiesInput.setText(state.getString("enemies", ""));
        bansInput.setText(state.getString("bans", ""));
        if (state.getBoolean("has_analyzed", false)) analyze();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void pad(View view, int value) {
        int amount = dp(value);
        view.setPadding(amount, amount, amount, amount);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(null, Typeface.BOLD);
        return view;
    }

    private LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private void base(String title, String subtitle) {
        LinearLayout root = vertical();
        root.setBackgroundColor(bg);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        scroll.setFillViewport(true);
        scroll.addView(root);
        applyInsets(scroll);
        setContentView(scroll);

        LinearLayout header = vertical();
        pad(header, 20);
        header.setBackground(shape(panel, 0));
        header.addView(text("⚔  BRAWL DRAFT AI", 20, white, true));
        TextView sub = text(subtitle, 13, muted, false);
        sub.setPadding(0, dp(5), 0, 0);
        header.addView(sub);
        root.addView(header);

        content = vertical();
        pad(content, 18);
        root.addView(content);
        content.addView(text(title, 24, white, true));
    }

    private void applyInsets(View view) {
        view.setOnApplyWindowInsetsListener((target, insets) -> {
            int left;
            int top;
            int right;
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets systemInsets = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                left = systemInsets.left;
                top = systemInsets.top;
                right = systemInsets.right;
                bottom = systemInsets.bottom;
            } else {
                left = insets.getSystemWindowInsetLeft();
                top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight();
                bottom = insets.getSystemWindowInsetBottom();
            }
            target.setPadding(left, top, right, bottom);
            return insets;
        });
    }

    private void label(String value) {
        TextView view = text(value, 13, muted, true);
        view.setPadding(0, dp(17), 0, dp(6));
        content.addView(view);
    }

    private TextView spinnerText(String value) {
        TextView view = text(value, 14, white, false);
        view.setGravity(Gravity.CENTER_VERTICAL);
        view.setPadding(dp(12), dp(10), dp(12), dp(10));
        return view;
    }

    private Spinner spinner(String[] options) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, options) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                return spinnerText(getItem(position));
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView item = spinnerText(getItem(position));
                item.setBackgroundColor(panel);
                return item;
            }
        };
        spinner.setAdapter(adapter);
        spinner.setBackground(shape(panel, 14));
        spinner.setPopupBackgroundDrawable(shape(panel, 12));
        content.addView(spinner);
        return spinner;
    }

    private EditText edit(String hint) {
        EditText field = new EditText(this);
        field.setSingleLine(false);
        field.setMinLines(1);
        field.setMaxLines(3);
        field.setTextColor(white);
        field.setHintTextColor(muted);
        field.setHint(hint);
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        field.setImeOptions(EditorInfo.IME_ACTION_DONE);
        field.setBackground(shape(panel, 14));
        pad(field, 12);
        content.addView(field);
        return field;
    }

    private void button(String title, Runnable action) {
        Button button = new Button(this);
        button.setText(title);
        button.setTextColor(white);
        button.setAllCaps(false);
        button.setBackground(shape(blue, 15));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(14);
        content.addView(button, params);
        button.setOnClickListener(view -> action.run());
    }

    private void nav() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(4), dp(12), dp(4), dp(12));
        String[] names = {"Início", "Pesquisa", "Comps", "Perfil"};
        for (String name : names) {
            TextView item = text(name, 13, white, true);
            item.setGravity(Gravity.CENTER);
            row.addView(item, new LinearLayout.LayoutParams(0, -2, 1));
            if (!name.equals("Início")) {
                item.setOnClickListener(view -> Toast.makeText(this,
                        name + " ainda não está implementado nesta versão.", Toast.LENGTH_SHORT).show());
            }
        }
        content.addView(row, 1);
    }

    private void showHome() {
        base("Análise de Draft", "Versão 0.3 • análise manual local");
        nav();

        label("NOME DO MAPA (OPCIONAL)");
        mapNameInput = edit("Ex.: nome do mapa da rotação");

        label("PERFIL DO MAPA (ESCOLHA MANUAL)");
        mapProfileSpinner = spinner(new String[]{
                "Equilibrado / desconhecido",
                "Aberto / poucas paredes",
                "Muitos arbustos",
                "Paredes e corredores"
        });

        TextView mapNote = text("O nome do mapa é apenas uma referência visual. O app não identifica a geometria automaticamente; a pontuação usa somente o perfil selecionado.",
                12, muted, false);
        mapNote.setPadding(dp(2), dp(6), dp(2), 0);
        content.addView(mapNote);

        label("MODO DE JOGO");
        modeSpinner = spinner(new String[]{
                "Pique-Gema", "Fute-Brawl", "Zona Estratégica", "Nocaute",
                "Caça-Estrelas", "Roubo", "Wipeout"
        });

        label("SEUS BRAWLERS / ALIADOS");
        alliesInput = edit("Ex.: Poco, Max (separe por vírgula)");
        label("BRAWLERS INIMIGOS");
        enemiesInput = edit("Ex.: Mortis, Edgar");
        label("BANS (OPCIONAL)");
        bansInput = edit("Ex.: Shelly, Spike");

        button("ANALISAR DRAFT", this::analyze);

        TextView note = text("O elenco reconhecido contém 111 Brawlers. 25 têm perfis detalhados nesta versão; os demais usam uma avaliação mais geral baseada na classe. Não há win rates nem dados ao vivo.",
                12, muted, false);
        note.setPadding(dp(2), dp(16), dp(2), 0);
        content.addView(note);

        resultArea = vertical();
        resultArea.setPadding(0, dp(12), 0, 0);
        content.addView(resultArea);
    }

    private void analyze() {
        String mapProfile = String.valueOf(mapProfileSpinner.getSelectedItem());
        String mapName = mapNameInput.getText().toString().trim();
        String mode = String.valueOf(modeSpinner.getSelectedItem());
        String allies = alliesInput.getText().toString();
        String enemies = enemiesInput.getText().toString();
        String bans = bansInput.getText().toString();

        List<DraftEngine.Result> picks = DraftEngine.recommend(mapProfile, mode,
                allies, enemies, bans, 3);
        resultArea.removeAllViews();
        resultArea.addView(text("MELHORES OPÇÕES", 16, white, true));
        String mapLabel = mapName.isEmpty() ? mapProfile : mapName + " • " + mapProfile;
        resultArea.addView(text(mapLabel + " • " + mode, 12, muted, false));

        List<String> unknown = new ArrayList<>();
        unknown.addAll(DraftEngine.unknownNames(allies));
        unknown.addAll(DraftEngine.unknownNames(enemies));
        unknown.addAll(DraftEngine.unknownNames(bans));
        unknown = unique(unknown);
        if (!unknown.isEmpty()) {
            TextView unknownWarning = text("Nomes não reconhecidos e ignorados: " + join(unknown),
                    12, warning, true);
            unknownWarning.setPadding(0, dp(10), 0, 0);
            resultArea.addView(unknownWarning);
        }

        if (picks.isEmpty()) {
            resultArea.addView(text("Nenhuma recomendação disponível. Confira os Brawlers informados.",
                    14, muted, false));
        } else {
            int rank = 1;
            for (DraftEngine.Result result : picks) {
                LinearLayout card = vertical();
                pad(card, 14);
                card.setBackground(shape(panel, 16));
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
                params.topMargin = dp(10);
                resultArea.addView(card, params);

                card.addView(text("#" + rank + "  " + result.name, 19, white, true));
                TextView score = text("Compatibilidade heurística: " + result.score + "/100",
                        12, green, true);
                score.setPadding(0, dp(4), 0, dp(6));
                card.addView(score);
                card.addView(text(result.explanation, 13, muted, false));
                if (!result.detailedProfile) {
                    TextView basic = text("Perfil básico: esta recomendação usa principalmente a classe do Brawler.",
                            11, warning, false);
                    basic.setPadding(0, dp(6), 0, 0);
                    card.addView(basic);
                }
                rank++;
            }
        }

        TextView disclaimer = text("A pontuação serve apenas para ordenar sugestões pelas regras locais. Não é porcentagem de vitória, tier list ou garantia de melhor escolha. Confira os mapas, o balanceamento e o contexto da partida.",
                12, muted, false);
        disclaimer.setPadding(0, dp(14), 0, 0);
        resultArea.addView(disclaimer);
    }

    private List<String> unique(List<String> values) {
        return new ArrayList<>(new LinkedHashSet<>(values));
    }

    private String join(List<String> values) {
        StringBuilder builder = new StringBuilder();
        for (String value : values) {
            if (builder.length() > 0) builder.append(", ");
            builder.append(value);
        }
        return builder.toString();
    }
}
