package com.brawldraftai.app;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Motor local de recomendações. As pontuações são heurísticas explicáveis,
 * não win rates, previsões estatísticas ou dados oficiais em tempo real.
 */
public final class DraftEngine {
    private DraftEngine() { }

    private static final int MAX_RECOMMENDATIONS = 3;
    private static final int BASE_SCORE = 45;

    public static final class Result {
        public final String name;
        public final int score;
        public final String explanation;
        public final boolean detailedProfile;

        Result(String name, int score, String explanation, boolean detailedProfile) {
            this.name = name;
            this.score = score;
            this.explanation = explanation;
            this.detailedProfile = detailedProfile;
        }
    }

    private static final class Brawler {
        final String name;
        final Set<String> roles = new HashSet<>();
        final Set<String> tags = new HashSet<>();
        final Set<String> counters = new HashSet<>();
        final Set<String> synergies = new HashSet<>();
        boolean detailed;

        Brawler(String name, String classRole) {
            this.name = name;
            addCsv(roles, classRole);
        }
    }

    private static final List<Brawler> ROSTER = new ArrayList<>();
    private static final Map<String, Brawler> BY_KEY = new HashMap<>();
    private static final Map<String, String> ALIASES = new HashMap<>();

    static {
        // Classes gerais do elenco. Perfis resumidos recebem apenas recomendações
        // baseadas na classe, sem inventar counters ou atributos específicos.
        addBasic("Bibi", "tanque");
        addBasic("Bo", "controle");
        addBasic("Bolt", "tanque");
        addBasic("Doug", "suporte");
        addBasic("Hank", "tanque");
        addBasic("Jacky", "tanque");
        addBasic("Jessie", "controle");
        addBasic("Juju", "artilharia");
        addBasic("Mr. P", "controle");
        addBasic("Nita", "dano");
        addBasic("Rosa", "tanque");
        addBasic("8-Bit", "dano");
        addBasic("Amber", "controle");
        addBasic("Ash", "tanque");
        addBasic("Bull", "tanque");
        addBasic("Chuck", "controle");
        addBasic("Clancy", "dano");
        addBasic("Damian", "tanque");
        addBasic("Edgar", "assassino");
        addBasic("El Primo", "tanque");
        addBasic("Emz", "controle");
        addBasic("Eve", "dano");
        addBasic("Frank", "tanque");
        addBasic("Grom", "artilharia");
        addBasic("Larry & Lawrie", "artilharia");
        addBasic("Mico", "assassino");
        addBasic("Ollie", "tanque");
        addBasic("Pam", "suporte");
        addBasic("Sandy", "controle");
        addBasic("Tara", "dano");
        addBasic("Tick", "artilharia");
        addBasic("Trunk", "tanque");
        addBasic("Willow", "controle");
        addBasic("Angelo", "atirador");
        addBasic("Bonnie", "atirador");
        addBasic("Brock", "atirador");
        addBasic("Buster", "tanque");
        addBasic("Carl", "dano");
        addBasic("Darryl", "tanque");
        addBasic("Draco", "tanque");
        addBasic("Dynamike", "artilharia");
        addBasic("Gale", "controle");
        addBasic("Griff", "controle");
        addBasic("Janet", "atirador");
        addBasic("Kenji", "assassino");
        addBasic("Leon", "assassino");
        addBasic("Melodie", "assassino");
        addBasic("Mortis", "assassino");
        addBasic("Najia", "dano");
        addBasic("Pearl", "dano");
        addBasic("Penny", "controle");
        addBasic("Poco", "suporte");
        addBasic("R-T", "dano");
        addBasic("Rico", "dano");
        addBasic("Sam", "assassino");
        addBasic("Shelly", "dano");
        addBasic("Sprout", "artilharia");
        addBasic("Starr Nova", "assassino");
        addBasic("Surge", "dano");
        addBasic("Wendy", "suporte");
        addBasic("Barley", "artilharia");
        addBasic("Bea", "atirador");
        addBasic("Belle", "atirador");
        addBasic("Buzz", "assassino");
        addBasic("Chester", "dano");
        addBasic("Colette", "dano");
        addBasic("Colt", "dano");
        addBasic("Cordelius", "assassino");
        addBasic("Fang", "assassino");
        addBasic("Finx", "controle");
        addBasic("Glowy", "suporte");
        addBasic("Gray", "suporte");
        addBasic("Gus", "suporte");
        addBasic("Lily", "assassino");
        addBasic("Lola", "dano");
        addBasic("Lou", "controle");
        addBasic("Maisie", "atirador");
        addBasic("Mandy", "atirador");
        addBasic("Meg", "tanque");
        addBasic("Nani", "atirador");
        addBasic("Nori", "assassino");
        addBasic("Otis", "controle");
        addBasic("Piper", "atirador");
        addBasic("Shade", "assassino");
        addBasic("Sirius", "controle");
        addBasic("Spike", "dano");
        addBasic("Ziggy", "controle");
        addBasic("Alli", "assassino");
        addBasic("Byron", "suporte");
        addBasic("Charlie", "controle");
        addBasic("Cosmo", "controle");
        addBasic("Crow", "assassino");
        addBasic("Gene", "controle");
        addBasic("Gigi", "assassino");
        addBasic("Jae-Yong", "suporte");
        addBasic("Kaze", "assassino");
        addBasic("Kit", "suporte");
        addBasic("Meeple", "controle");
        addBasic("Mina", "dano");
        addBasic("Moe", "dano");
        addBasic("Squeak", "controle");
        addBasic("Stu", "assassino");
        addBasic("Vince", "dano");
        addBasic("Berry", "suporte");
        addBasic("Lumi", "dano");
        addBasic("Max", "suporte");
        addBasic("Pierce", "atirador");
        addBasic("Ruffs", "suporte");

        // Brawlers anunciados pela Supercell nas notas oficiais de 11/11/2026.
        addBasic("Sapos Voltaicos", "artilharia");
        addBasic("Rey", "atirador");
        addBasic("Ruby", "dano");

        // Perfis detalhados iniciais. São regras manuais e aproximadas, não dados
        // competitivos oficiais. Os nomes/classes do restante do elenco continuam
        // reconhecidos, mas recebem uma avaliação mais conservadora.
        detail("Belle", "atirador,alcance,controle", "aberto,pressao,marcacao", "tanque,curto", "controle,suporte");
        detail("Piper", "atirador,alcance,burst", "aberto,precisao", "curto,assassino", "controle,suporte");
        detail("Nani", "atirador,alcance,burst", "aberto,precisao", "curto,assassino", "controle");
        detail("Brock", "atirador,alcance", "aberto,destruicao,area", "agrupado,controle", "artilharia,alcance");
        detail("Bo", "controle", "arbusto,visao,area", "assassino,curto", "controle,artilharia");
        detail("Shelly", "dano,anti-tanque,curto", "arbusto,explosao", "tanque,assassino", "controle,curto");
        detail("Colt", "dano,alcance", "aberto,destruicao", "agrupado,curto", "controle,alcance");
        detail("Spike", "dano,controle,anti-tanque", "area,pressao", "tanque,agrupado", "controle,atirador");
        detail("Gene", "controle,suporte", "puxao,utilidade", "assassino,curto", "suporte,controle");
        detail("Max", "suporte,mobilidade", "mobilidade,pressao", "alcance,controle", "assassino,dano");
        detail("Sandy", "controle,suporte", "arbusto,utilidade", "agrupado,curto", "suporte,controle");
        detail("R-T", "dano,controle,anti-tanque", "alcance,marcacao", "tanque,curto", "controle,atirador");
        detail("Gale", "controle,anti-tanque", "defesa,area", "assassino,tanque", "controle,tanque");
        detail("Emz", "controle", "corredor,pressao,area", "curto,agrupado", "controle,artilharia");
        detail("Stu", "assassino,mobilidade", "mobilidade,pressao", "alcance,controle", "assassino,suporte");
        detail("Crow", "assassino,controle", "mobilidade,anti-cura", "suporte,curto", "assassino,pressao");
        detail("Jessie", "controle", "objetivo,torreta,area", "agrupado,curto", "controle,artilharia");
        detail("Rico", "dano,controle", "parede,corredor,ricochete", "curto,agrupado", "controle,alcance");
        detail("Frank", "tanque,curto", "parede,objetivo", "controle,anti-tanque", "suporte,controle");
        detail("Edgar", "assassino,curto", "mobilidade,explosao", "alcance,controle", "assassino,suporte");
        detail("Mortis", "assassino,mobilidade", "mobilidade,limpeza", "controle,anti-tanque", "assassino,suporte");
        detail("Buzz", "assassino,curto", "arbusto,engage", "alcance,controle", "assassino,controle");
        detail("Poco", "suporte", "cura,objetivo", "anti-cura,burst", "tanque,assassino");
        detail("8-Bit", "dano,alcance", "objetivo,torreta", "assassino,curto", "alcance,suporte");
        detail("Tick", "artilharia,controle", "parede,area", "assassino,mobilidade", "controle,atirador");

        for (Brawler b : ROSTER) {
            String key = normalize(b.name);
            BY_KEY.put(key, b);
            ALIASES.put(key, b.name);
        }
        addAlias("8bit", "8-Bit");
        addAlias("rt", "R-T");
        addAlias("mrp", "Mr. P");
        addAlias("misterp", "Mr. P");
        addAlias("larryandlawrie", "Larry & Lawrie");
        addAlias("larrylawrie", "Larry & Lawrie");
        addAlias("elprimo", "El Primo");
        addAlias("starrnova", "Starr Nova");
    }

    private static void addBasic(String name, String classRole) {
        ROSTER.add(new Brawler(name, classRole));
    }

    private static void detail(String name, String roles, String tags,
                               String counters, String synergies) {
        Brawler b = findInRoster(name);
        if (b == null) {
            throw new IllegalStateException("Brawler não encontrado no elenco: " + name);
        }
        b.roles.clear();
        addCsv(b.roles, roles);
        addCsv(b.tags, tags);
        addCsv(b.counters, counters);
        addCsv(b.synergies, synergies);
        b.detailed = true;
    }

    private static Brawler findInRoster(String name) {
        String key = normalize(name);
        for (Brawler b : ROSTER) {
            if (normalize(b.name).equals(key)) return b;
        }
        return null;
    }

    private static void addAlias(String alias, String canonical) {
        ALIASES.put(alias, canonical);
    }

    private static void addCsv(Set<String> destination, String csv) {
        if (csv == null || csv.trim().isEmpty()) return;
        for (String value : csv.split(",")) {
            String item = normalize(value);
            if (!item.isEmpty()) destination.add(item);
        }
    }

    private static String normalize(String value) {
        if (value == null) return "";
        String decomposed = Normalizer.normalize(value.trim(), Normalizer.Form.NFD);
        String withoutMarks = decomposed.replaceAll("\\p{M}+", "");
        return withoutMarks.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    private static List<Brawler> parse(String input) {
        List<Brawler> result = new ArrayList<>();
        if (input == null || input.trim().isEmpty()) return result;
        Set<String> seen = new HashSet<>();
        for (String raw : input.split("[,;\\n]+")) {
            String key = normalize(raw);
            String canonical = ALIASES.get(key);
            if (canonical == null) continue;
            Brawler brawler = BY_KEY.get(normalize(canonical));
            if (brawler != null && seen.add(normalize(brawler.name))) result.add(brawler);
        }
        return result;
    }

    public static List<String> unknownNames(String input) {
        List<String> unknown = new ArrayList<>();
        if (input == null || input.trim().isEmpty()) return unknown;
        Set<String> seen = new HashSet<>();
        for (String raw : input.split("[,;\\n]+")) {
            String name = raw.trim();
            String key = normalize(name);
            if (!key.isEmpty() && !ALIASES.containsKey(key) && seen.add(key)) {
                unknown.add(name);
            }
        }
        return unknown;
    }

    public static int getRosterCount() {
        return ROSTER.size();
    }

    public static boolean isKnownBrawler(String name) {
        return ALIASES.containsKey(normalize(name));
    }

    public static List<Result> recommend(String mapProfile, String mode, String alliesText,
                                         String enemiesText, String bansText, int limit) {
        int safeLimit = Math.max(0, Math.min(MAX_RECOMMENDATIONS, limit));
        if (safeLimit == 0) return new ArrayList<>();

        List<Brawler> allies = parse(alliesText);
        List<Brawler> enemies = parse(enemiesText);
        List<Brawler> bans = parse(bansText);
        Set<Brawler> unavailable = new HashSet<>();
        unavailable.addAll(allies);
        unavailable.addAll(enemies);
        unavailable.addAll(bans);

        String map = normalize(mapProfile);
        String gameMode = normalize(mode);
        List<Result> results = new ArrayList<>();

        for (Brawler candidate : ROSTER) {
            if (unavailable.contains(candidate)) continue;
            int score = BASE_SCORE;
            List<String> reasons = new ArrayList<>();

            score += mapFit(candidate, map, reasons);
            score += modeFit(candidate, gameMode, reasons);
            score += counterFit(candidate, enemies, reasons);
            score += synergyFit(candidate, allies, reasons);
            score += compositionFit(candidate, allies, reasons);

            if (!candidate.detailed) {
                score -= 3;
                reasons.add("perfil resumido: avaliação baseada principalmente na classe");
            }

            score = Math.max(0, Math.min(100, score));
            String explanation = joinUnique(reasons, 2);
            if (explanation.isEmpty()) {
                explanation = "opção geral; faltam dados específicos deste mapa e confronto";
            }
            results.add(new Result(candidate.name, score, explanation, candidate.detailed));
        }

        Collections.sort(results, new Comparator<Result>() {
            @Override public int compare(Result left, Result right) {
                int byScore = Integer.compare(right.score, left.score);
                return byScore != 0 ? byScore : left.name.compareToIgnoreCase(right.name);
            }
        });

        if (results.size() > safeLimit) {
            return new ArrayList<>(results.subList(0, safeLimit));
        }
        return results;
    }

    private static int mapFit(Brawler candidate, String map, List<String> reasons) {
        if (map.contains("aberto") || map.contains("poucasparedes")) {
            if (candidate.roles.contains("atirador") || candidate.roles.contains("alcance")) {
                reasons.add("alcance favorece mapas abertos");
                return 8;
            }
            if (candidate.roles.contains("tanque") || candidate.roles.contains("assassino")) return -2;
        } else if (map.contains("arbusto")) {
            if (candidate.tags.contains("arbusto") || candidate.roles.contains("assassino")
                    || candidate.roles.contains("tanque")) {
                reasons.add("pode aproveitar cobertura e arbustos");
                return 7;
            }
        } else if (map.contains("parede") || map.contains("corredor")) {
            if (candidate.tags.contains("parede") || candidate.tags.contains("corredor")
                    || candidate.tags.contains("ricochete") || candidate.roles.contains("artilharia")) {
                reasons.add("kit combina com paredes e corredores");
                return 8;
            }
            if (candidate.tags.contains("destruicao")) {
                reasons.add("pode modificar a cobertura do mapa");
                return 4;
            }
        }
        return 0;
    }

    private static int modeFit(Brawler candidate, String mode, List<String> reasons) {
        if (mode.contains("piquegema") || mode.contains("gemgrab")) {
            if (candidate.roles.contains("controle") || candidate.roles.contains("suporte")) {
                reasons.add("ajuda a controlar a região central e apoiar a equipe");
                return 8;
            }
        } else if (mode.contains("futebrawl") || mode.contains("brawlball")) {
            if (candidate.roles.contains("tanque") || candidate.roles.contains("assassino")) {
                reasons.add("pode criar pressão para avançar com a bola");
                return 7;
            }
            if (candidate.roles.contains("suporte") || candidate.tags.contains("defesa")) {
                reasons.add("pode apoiar a defesa e a progressão");
                return 4;
            }
        } else if (mode.contains("zona") || mode.contains("hotzone")) {
            if (candidate.roles.contains("controle") || candidate.roles.contains("tanque")) {
                reasons.add("favorece disputa e permanência na zona");
                return 8;
            }
            if (candidate.roles.contains("artilharia") || candidate.roles.contains("suporte")) return 3;
        } else if (mode.contains("nocaute") || mode.contains("knockout")) {
            if (candidate.roles.contains("atirador") || candidate.roles.contains("assassino")) {
                reasons.add("pode pressionar em confrontos de eliminação");
                return 8;
            }
            if (candidate.roles.contains("artilharia")) return 3;
        } else if (mode.contains("cacaestrelas")
                || mode.contains("bounty")) {
            if (candidate.roles.contains("atirador")) {
                reasons.add("alcance ajuda a disputar eliminações com segurança");
                return 8;
            }
            if (candidate.roles.contains("assassino")) return 3;
        } else if (mode.contains("roubo") || mode.contains("heist")) {
            if (candidate.roles.contains("dano") || candidate.roles.contains("artilharia")) {
                reasons.add("pode contribuir com dano ao objetivo");
                return 8;
            }
        } else if (mode.contains("wipeout") || mode.contains("eliminacao")) {
            if (candidate.roles.contains("atirador") || candidate.roles.contains("assassino")) {
                reasons.add("tem perfil útil para buscar eliminações");
                return 6;
            }
        }
        return 0;
    }

    private static int counterFit(Brawler candidate, List<Brawler> enemies, List<String> reasons) {
        int total = 0;
        for (Brawler enemy : enemies) {
            boolean explicitCounter = intersects(candidate.counters, enemy.roles)
                    || intersects(candidate.counters, enemy.tags);
            boolean broadCounter = (enemy.roles.contains("tanque")
                    && candidate.roles.contains("anti-tanque"))
                    || (enemy.roles.contains("assassino")
                    && (candidate.roles.contains("controle") || candidate.roles.contains("anti-tanque")));
            if (explicitCounter || broadCounter) {
                int bonus = explicitCounter ? 6 : 3;
                total += bonus;
                reasons.add("tem ferramentas de resposta contra " + enemy.name);
            }
        }
        return Math.min(12, total);
    }

    private static int synergyFit(Brawler candidate, List<Brawler> allies, List<String> reasons) {
        int total = 0;
        for (Brawler ally : allies) {
            boolean explicit = intersects(candidate.synergies, ally.roles);
            boolean general = (candidate.roles.contains("suporte")
                    && (ally.roles.contains("tanque") || ally.roles.contains("assassino")
                    || ally.roles.contains("dano") || ally.roles.contains("atirador")))
                    || (candidate.roles.contains("controle") && ally.roles.contains("atirador"))
                    || (candidate.roles.contains("tanque") && ally.roles.contains("suporte"));
            if (explicit || general) {
                total += explicit ? 4 : 2;
                reasons.add("complementa a função de " + ally.name);
            }
        }
        return Math.min(8, total);
    }

    private static int compositionFit(Brawler candidate, List<Brawler> allies,
                                       List<String> reasons) {
        boolean hasControl = false;
        boolean hasSupport = false;
        boolean hasDamage = false;
        for (Brawler ally : allies) {
            hasControl |= ally.roles.contains("controle");
            hasSupport |= ally.roles.contains("suporte");
            hasDamage |= ally.roles.contains("dano") || ally.roles.contains("atirador")
                    || ally.roles.contains("assassino") || ally.roles.contains("artilharia");
        }

        int bonus = 0;
        if (!hasControl && candidate.roles.contains("controle")) {
            bonus += 4;
            reasons.add("acrescenta controle à composição");
        }
        if (!hasSupport && candidate.roles.contains("suporte")) {
            bonus += 2;
            reasons.add("acrescenta suporte à equipe");
        }
        if (!hasDamage && (candidate.roles.contains("dano") || candidate.roles.contains("atirador")
                || candidate.roles.contains("assassino") || candidate.roles.contains("artilharia"))) {
            bonus += 3;
            reasons.add("acrescenta pressão ofensiva à composição");
        }
        return bonus;
    }

    private static boolean intersects(Set<String> first, Set<String> second) {
        for (String value : first) if (second.contains(value)) return true;
        return false;
    }

    private static String joinUnique(List<String> values, int max) {
        LinkedHashSet<String> unique = new LinkedHashSet<>(values);
        StringBuilder output = new StringBuilder();
        int count = 0;
        for (String value : unique) {
            if (output.length() > 0) output.append("; ");
            output.append(value);
            count++;
            if (count >= max) break;
        }
        return output.toString();
    }
}
