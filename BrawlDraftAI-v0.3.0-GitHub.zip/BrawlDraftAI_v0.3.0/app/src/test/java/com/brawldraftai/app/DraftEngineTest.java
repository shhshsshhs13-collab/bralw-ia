package com.brawldraftai.app;

import org.junit.Test;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.*;

public class DraftEngineTest {
    @Test public void rosterContainsCurrentReferenceSet() {
        assertEquals(111, DraftEngine.getRosterCount());
        assertTrue(DraftEngine.isKnownBrawler("Sapos Voltaicos"));
        assertTrue(DraftEngine.isKnownBrawler("Rey"));
        assertTrue(DraftEngine.isKnownBrawler("Ruby"));
        assertTrue(DraftEngine.isKnownBrawler("Larry & Lawrie"));
        assertTrue(DraftEngine.isKnownBrawler("8bit"));
        assertTrue(DraftEngine.isKnownBrawler("Mr. P"));
    }

    @Test public void accentsAndAliasesAreNormalized() {
        assertTrue(DraftEngine.unknownNames("Piper, 8-bit; MR P").isEmpty());
        assertTrue(DraftEngine.unknownNames("Píper").isEmpty());
    }

    @Test public void bannedAndAlreadyPickedBrawlersAreNeverRecommended() {
        List<DraftEngine.Result> picks = DraftEngine.recommend(
                "Aberto / poucas paredes", "Pique-Gema", "Poco", "Mortis", "Spike", 3);
        for (DraftEngine.Result pick : picks) {
            assertNotEquals("Poco", pick.name);
            assertNotEquals("Mortis", pick.name);
            assertNotEquals("Spike", pick.name);
        }
    }

    @Test public void recommendationLimitIsSafeAndNeverExceedsThree() {
        assertTrue(DraftEngine.recommend("Equilibrado", "Nocaute", "", "", "", 0).isEmpty());
        assertTrue(DraftEngine.recommend("Equilibrado", "Nocaute", "", "", "", -3).isEmpty());
        assertTrue(DraftEngine.recommend("Equilibrado", "Nocaute", "", "", "", 100).size() <= 3);
    }

    @Test public void resultsAreSortedAndScoresStayWithinRange() {
        List<DraftEngine.Result> picks = DraftEngine.recommend(
                "Paredes e corredores", "Roubo", "Poco, Max", "Frank, Edgar", "Tick", 3);
        assertTrue(picks.size() <= 3);
        for (int i = 0; i < picks.size(); i++) {
            assertTrue(picks.get(i).score >= 0 && picks.get(i).score <= 100);
            if (i > 0) assertTrue(picks.get(i - 1).score >= picks.get(i).score);
        }
    }

    @Test public void explicitCounterDataChangesTheRecommendationScore() {
        int withoutEnemy = scoreOf("Belle", DraftEngine.recommend(
                "Equilibrado", "Pique-Gema", "", "", "", 3));
        int againstFrank = scoreOf("Belle", DraftEngine.recommend(
                "Equilibrado", "Pique-Gema", "", "Frank", "", 3));
        assertTrue("Belle should receive a counter bonus against Frank", againstFrank > withoutEnemy);
    }

    @Test public void duplicateInputsDoNotDuplicateResultsOrWarnings() {
        assertEquals(1, DraftEngine.unknownNames("Mystery, mystery; MYSTERY").size());
        List<DraftEngine.Result> picks = DraftEngine.recommend(
                "Equilibrado", "Nocaute", "Poco, Poco", "", "", 3);
        Set<String> names = new HashSet<>();
        for (DraftEngine.Result pick : picks) assertTrue(names.add(pick.name));
    }

    @Test public void emptyInputsStillReturnSafeGeneralSuggestions() {
        List<DraftEngine.Result> picks = DraftEngine.recommend(null, null, null, null, null, 3);
        assertEquals(3, picks.size());
        for (DraftEngine.Result pick : picks) assertNotNull(pick.explanation);
    }

    private int scoreOf(String name, List<DraftEngine.Result> results) {
        for (DraftEngine.Result result : results) if (result.name.equals(name)) return result.score;
        fail("Expected brawler not found: " + name);
        return -1;
    }
}
