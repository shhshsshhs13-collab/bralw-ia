# Brawl Draft AI — projeto Android inicial

Versão 0.3.0: protótipo Android nativo em Java, com análise manual e local de draft.

## O que esta versão faz

- Reconhece 111 nomes de Brawlers na base local.
- Usa 25 perfis detalhados com funções, atributos aproximados, counters e sinergias manuais.
- Para os outros Brawlers, usa apenas a classe geral; esses resultados são identificados como perfis básicos.
- Permite informar o nome do mapa e escolher manualmente um perfil: aberto, arbustos, paredes/corredores ou equilibrado/desconhecido. O nome é apenas um rótulo; o perfil selecionado é o que afeta a análise.
- Permite escolher Pique-Gema, Fute-Brawl, Zona Estratégica, Nocaute, Caça-Estrelas, Roubo ou Wipeout.
- Considera aliados, inimigos e bans; Brawlers já escolhidos ou banidos não aparecem nas recomendações.
- Retorna até três sugestões, com compatibilidade heurística de 0 a 100 e explicações curtas.
- Avisos identificam nomes digitados que não estão na base.
- Preserva o draft preenchido durante uma recriação normal da Activity.
- Não solicita login, permissões de captura de tela, acesso ao jogo ou permissões de rede.

## Limitações conhecidas

- A base foi formada com 108 perfis de uma referência comunitária consultada em 07/11/2026 e recebeu mais três nomes anunciados nas notas oficiais da Supercell de 11/11/2026 (Sapos Voltaicos, Rey e Ruby). Lançamentos posteriores podem exigir atualização.
- Os 25 perfis detalhados são regras manuais aproximadas, ainda não validadas por testes competitivos abrangentes. Não trate counters ou sinergias como verdades universais.
- Os demais 86 perfis usam apenas a classe geral. Não há atributos específicos, counters ou sinergias individuais cadastrados para eles.
- Os perfis de mapa são escolhidos pelo usuário. O app não reconhece mapas, paredes, arbustos ou rotas automaticamente.
- Os pesos da pontuação são regras internas. A pontuação não é win rate, probabilidade de vitória, tier list nem garantia de melhor escolha.
- Não há API oficial, estatísticas ao vivo, atualização automática, OCR, overlay, captura de tela, conta de usuário, nuvem ou banco de dados remoto.
- Pesquisa, Comps e Perfil aparecem como áreas futuras; ainda não são funcionalidades implementadas.
- A lista de modos desta versão é limitada e não representa todas as variantes, modos temporários ou regras de cada temporada.

## Testes incluídos

Os testes unitários verificam o tamanho do elenco local, aliases e acentos, exclusão de picks/bans, limites de recomendações, ordenação, limites da pontuação, uso dos counters, duplicatas e drafts vazios.

## Como compilar localmente

Requisitos: JDK 17+, Android SDK Platform 35, Android Build-Tools 35.0.0 e Android Gradle Plugin 8.6.1.

Em Linux/macOS, primeiro torne o wrapper executável:

```bash
chmod +x ./gradlew
./gradlew testDebugUnitTest assembleDebug
```

No Windows, use `gradlew.bat testDebugUnitTest assembleDebug`.

O APK debug, se a compilação terminar com sucesso, fica em:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Compilar APK pelo GitHub Actions

1. Crie um repositório privado no GitHub.
2. Extraia o ZIP e envie o conteúdo da pasta `BrawlDraftAI_v2` para a raiz do repositório, incluindo a pasta oculta `.github`.
3. Abra a aba **Actions** e habilite os workflows, se o GitHub solicitar.
4. Selecione **Build Brawl Draft AI APK** e toque em **Run workflow**.
5. O workflow executa primeiro os testes unitários e depois compila o APK debug.
6. Quando a execução terminar com sucesso, baixe o artefato **BrawlDraftAI-debug-apk** na seção **Artifacts** e extraia o APK.

O workflow também é acionado por novos pushes em `main` ou `master`. O artefato é temporário e fica disponível por 14 dias. O APK debug serve para teste e não é uma versão assinada para publicação na Play Store.

Não compartilhe tokens do GitHub nem credenciais. O repositório pode permanecer privado.

## Referências consultadas para a base

- Lista comunitária com 108 perfis de Brawlers e classes, consultada em 07/11/2026: https://brawls.wiki/brawlers/?tier=Unranked
- Notas oficiais da Supercell de 11/11/2026, que apresentam Sapos Voltaicos, Rey e Ruby como novos Brawlers: https://supercell.com/brawlstars/pt/blog/game-updates/notas-de-lancamento-novembro-de-2026/
- Referência da Supercell sobre modos de jogo: https://sc-brawlstars.zendesk.com/hc/en-us/articles/49526599632923-Game-Modes

As fontes acima ajudam a identificar nomes, classes e contexto do jogo. Elas não validam a pontuação interna nem as recomendações heurísticas implementadas neste protótipo.
