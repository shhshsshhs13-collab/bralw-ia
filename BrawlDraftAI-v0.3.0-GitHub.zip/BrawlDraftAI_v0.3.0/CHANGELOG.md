# Alterações da versão 0.3.0

## Corrigido

- O campo `counters` agora participa do cálculo de resposta a classes e atributos dos inimigos.
- A lógica de sinergia foi separada da lógica de counters e limita os bônus para evitar pontuações excessivas.
- Limites inválidos ou acima de três recomendações não provocam exceções nem retornam mais de três resultados.
- Pontuações agora são explicitamente exibidas como compatibilidade heurística de 0 a 100, nunca como porcentagem de vitória.
- Nomes são normalizados sem distinção de maiúsculas, minúsculas ou acentos; aliases como `8bit`, `R-T` e `Mr. P` são reconhecidos.
- Duplicatas na entrada e na lista de nomes desconhecidos são removidas.
- Resultados empatados têm ordenação determinística.
- A interface deixa de sugerir que nomes específicos de mapas representam uma leitura real da geometria; agora o usuário escolhe um perfil de mapa manual.
- A interface mostra quando uma recomendação usa somente um perfil básico.
- A navegação Pesquisa, Comps e Perfil deixa claro que as áreas ainda não estão implementadas.
- Campos do draft são restaurados durante a recriação normal da Activity.
- A documentação foi alinhada à base local: 111 nomes reconhecidos, dos quais 25 possuem perfil detalhado.
- A versão Android foi atualizada para 0.3.0 (versionCode 2).

## Dados e transparência

- A base local reúne 111 nomes: 108 perfis da referência comunitária consultada em 07/11/2026, mais Sapos Voltaicos, Rey e Ruby anunciados nas notas oficiais da Supercell de 11/11/2026.
- Perfis detalhados continuam sendo aproximações manuais. Os outros Brawlers usam avaliação geral por classe, sem counters específicos inventados.
- Modos, mapas, balanceamento e regras de ranqueada podem mudar. Este protótipo não usa uma fonte de dados ao vivo.

## Testes

- Adicionados testes unitários para elenco, aliases, acentos, bans, picks já selecionados, limite de sugestões, ordenação, pontuação, counters, duplicatas e entradas vazias.
- GitHub Actions agora executa `testDebugUnitTest` antes de `assembleDebug`.
